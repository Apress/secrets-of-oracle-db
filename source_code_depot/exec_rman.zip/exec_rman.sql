BEGIN
	DBMS_SCHEDULER.CREATE_JOB(
		job_name => 'rman_online_backup',
		job_type => 'EXECUTABLE',
		job_action => 'c:\home\ndebes\bin\exec_rman.bat C:\home\ndebes\rman\TEN_config.bat backup_online.rcv',
		start_date => systimestamp,
		repeat_interval => 'FREQ=DAILY;BYHOUR=22',
		enabled=>true /* default false! */
	);
END;
/

